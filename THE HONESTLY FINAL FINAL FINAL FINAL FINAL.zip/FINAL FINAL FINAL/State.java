import java.awt.Graphics;

/**
 * Being an abstract class, the State class requires other states in its hierarchy to utilize its abstract method.
 * A state in this game is considered the "display" of the current game.
 * 
 * For instance, if the user is currently in the dungeon, then the user is in the DungeonState.
 * If the player has died, then the user is in the DiedState.
 * etc.
 */
public abstract class State 
{
    //class variables
    protected Handler myHandler;
    
    private static State currentState = null;
    
    //<<DEFAULT CONSTRUCTOR>>
    public State(Handler handler)
    {
        myHandler = handler;
    }
    
    /**
     * Sets the current state to a new one
     */
    public static void setState(State state)
    {
        currentState = state;
    }
    
    /**
     * Returns the current state of the game
     */
    public static State getState()
    {
        return currentState;
    }
    
    public abstract void tick();
    
    public abstract void render(Graphics g);
}
