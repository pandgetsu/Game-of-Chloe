/**
 * WallTile, it's a wall or something
 * @author Sean and JavaDocing by Brian
 */
public class WallTile extends Tile
{
    /**
     * Constructor for tile
     */
	public WallTile(int id)
	{
		super(Assets.wallTile, id);
	}
	
	/**
	 * Returns true because it's a wall
	 */
	public boolean isSolid()
	{
		return true;
	}
}
