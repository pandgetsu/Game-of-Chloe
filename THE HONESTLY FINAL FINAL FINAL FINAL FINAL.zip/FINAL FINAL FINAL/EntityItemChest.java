import java.awt.Graphics;
import java.awt.image.BufferedImage;

/**
 * Creates an chest entity
 * 
 * @author Sean Tran
 * @documenter Eric Kang
 * @version 1.0
 */
public class EntityItemChest extends EntityNonLiving
{
    private boolean isOpen;
    
    /**
     * Constructor for class EntityItemChest
     * Sets isOpen to false to close chest
     * 
     * @param handler       handler - allows access to other classes
     * @param x             x coordinate of the entity
     * @param y             y coordinate of the entity
     */
    public EntityItemChest(Handler handler, float x, float y) 
    {
        super(handler, x, y, Tile.TILE_WIDTH, Tile.TILE_HEIGHT);
        // TODO Auto-generated constructor stub

        isOpen = false;
    }
    
    /**
     * Empty tick
     */
    public void tick()
    {

    }
    
    /**
     * Checks if the entity is alive
     * USELESS METHOD
     * 
     * @return      true
     */
    public boolean isAlive()
    {
        return true;
    }
    
    /**
     * Gets the entity signiture
     * 
     * @return      string with entity signature (type of entity)
     */
    public String getEntitySignature()
    {
        return "chest";
    }
    
    /**
     * Performs the action of the entity
     */
    public void getAction()
    {
        // If the chest is not open
            // Check if the main character already has an item(key)
            // If so, set isOpen to true and give the player a key
            // Otherwise, state that the player may only have one key at a time
        if(!isOpen)
        {
            if(!myHandler.getInstance().getEntityHandler().getMainCharacter().hasItem())
            {
                isOpen = true;
                //System.out.println("Chest is opened!");
                myHandler.getInstance().getEntityHandler().getMainCharacter().setHasKey(true);
                System.out.println("Key acquired!");
            }else
            {
                System.out.println("You may only hold one item at a time!");
            }
        }
    }
    
    /**
     * Renders the image of the chest
     */
    public void render(Graphics g)
    {
        g.drawImage(getCurrentAnimation(), (int) getMyX(), (int) getMyY(), getMyWidth(), getMyHeight(), null);
    }
    
    /**
     * Gets the current animation of the entity
     * 
     * @return sprite of the entity
     */
    private BufferedImage getCurrentAnimation()
    {
        if(!isOpen)
        {
            return Assets.itemChest[0];
        }else
        {
            return Assets.itemChest[1];
        }
    }

}
