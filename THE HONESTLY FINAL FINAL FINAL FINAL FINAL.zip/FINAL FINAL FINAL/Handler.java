/**
 * This is the greatest class known within our circle of programmers.
 * 
 * This is the Handler class.
 * 
 * What is the Handler class you might ask?
 * 
 * It is the epitome of Object Oriented Programming.
 * 
 * Some may see it as primitive. I see it as a jewel.
 * 
 * Could there have been other methods of "handling" the operations done within this program? Yes.
 * 
 * Have we dug further to unlock those truths? Absolutely not.
 * 
 * I present to you, the Handler class, the class that allows you to access anything from anywhere.
 * 
 * @author Sean Tran
 */
public class Handler 
{
    //the beautiful class variables
    private DungeonGame myGame;
    private DungeonInstance myInstance;
    private DungeonGUI ashdasjd;
    private int myDungeon;
    
    //<<THE BEAUTIFUL DEFAULT CONSTRUCTOR>>
    public Handler(DungeonGame game)
    {
        myGame = game;
    }
    
    /**
     * RETURNS THE KEYBOARD :^)
     */
    public Keyboard getKeyboard()
    {
        return myGame.getKeyboard();
    }
    
    /**
     * ADDS A GUI TO THE HANDLER TO MAKE IT ACCESSIBLE :^)
     */
    public void addGUI(DungeonGUI gui)
    {
        ashdasjd = gui;
    }
    
    /**
     * RETURNS THE DUNGEONGUI :^)
     */
    public DungeonGUI getGUI()
    {
        return ashdasjd;
    }
    
    /**
     * RETURNS THE WIDTH OF THE GAME :^)
     */
    public int getWidth()
    {
        return myGame.getWidth();
    }
    
    /**
     * RETURNS THE HEIGHT OF THE GAME :^)
     */
    public int getHeight()
    {
        return myGame.getHeight();
    }
    
    /**
     * RETURNS THE GAME :^)
     */
    public DungeonGame getGame()
    {
        return myGame;
    }

    /**
     * SETS THE GAME :^)
     */
    public void setGame(DungeonGame game) 
    {
        myGame = game;
    }

    /**
     * RETURNS THE INSTANCE :^)
     */
    public DungeonInstance getInstance() 
    {
        return myInstance;
    }

    /**
     * SETS THE INSTANCE :^)
     */
    public void setInstance(DungeonInstance instance) 
    {
        myInstance = instance;
    }
    
    /**
     * GETS THE DUNGEON ID
     */
    public int getDungeon()
    {
        return myDungeon;
    }
    
    /**
     * SETS THE DUNGEON ID
     */
    public void setDungeon(int d)
    {
        myDungeon = d;
    }

}
