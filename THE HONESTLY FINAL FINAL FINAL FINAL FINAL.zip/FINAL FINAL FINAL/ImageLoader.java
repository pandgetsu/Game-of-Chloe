import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;

/**
 * Creates an object to load images
 * 
 * @author Sean Tran
 * @documenter Eric Kang
 * @version 1.0
 */
public class ImageLoader 
{
    /**
     * Loads in the image
     * 
     * @param path      path of the file that is being read in
     * 
     * @return          buffered image from file
     *                  if unable, return null
     */
    public static BufferedImage loadImage(String path)
    {
        try 
        {
            return ImageIO.read(ImageLoader.class.getResource(path));
        } catch (IOException e) 
        {
            e.printStackTrace();
            System.exit(1);
        }
        return null;
    }

}