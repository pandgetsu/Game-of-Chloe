import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import javax.swing.*;
import java.awt.*;

/**
 * The Keyboard class handles most of the keybinds that will be usable throughout the Dungeon portion of the
 * program.
 */
public class Keyboard implements KeyListener
{
    //class variables
    private boolean[] keys;
    
    public boolean moveUp;
    public boolean moveDown;
    public boolean moveLeft;
    public boolean moveRight;
    
    public boolean interact;    
    
    public boolean resetWorld;
    
    public boolean slowDown;
    public boolean shoot;
    public boolean shield;
    
    private Handler myHandler;
    
    //<<DEFAULT CONSTRUCTOR>>
    public Keyboard()
    {
        keys = new boolean[99]; //creates a boolean array of keys
    }
    
    public void tick()
    {
        //movement keybinds
        moveUp = keys[KeyEvent.VK_W];
        moveDown = keys[KeyEvent.VK_S];
        moveLeft = keys[KeyEvent.VK_A];
        moveRight = keys[KeyEvent.VK_D];
        
        //player utility keybinds
        interact = keys[KeyEvent.VK_SPACE];
        //slowDown = keys[KeyEvent.VK_SHIFT];
        shoot = keys[KeyEvent.VK_J];
        
        shield = keys[KeyEvent.VK_SHIFT];
        resetWorld = keys[KeyEvent.VK_NUMPAD0];
        //InputMap test = ((JComponent)(myHandler.getGUI())).getInputMap();
    }
    
    /**
     * Adds a handler. Everything is connected to the handler.
     */
    public void addHandler(Handler handler)
    {
        myHandler = handler;
    }
    
    /**
     * The keyPressed() method sets the boolean of a specific key to true,
     * signaling that the key has been pressed.
     */
    public void keyPressed(KeyEvent e) 
    {
        keys[e.getKeyCode()] = true;
        
        //System.out.println(e.getKeyCode() + " pressed.");
    }

    /**
     * The keyReleased() method sets the boolean of a specific key to false,
     * signaling that the key has been released.
     */
    public void keyReleased(KeyEvent e) 
    {
        keys[e.getKeyCode()] = false;
        //isKeyPressed = false;
    }

    /**
     * Supposedly invoked when a key has been typed, but it has yet
     * to be implemented to the program.
     * 
     * Not a core method.
     */
    public void keyTyped(KeyEvent e)
    {
        //unused
    }

}
