/**
 * Creates a non living entity (Does not move)
 * 
 * @author Sean Tran
 * @documenter Eric Kang
 * @version 1.0
 */
public abstract class EntityNonLiving extends Entity
{
    /**
     * Creates a new EntityNonLiving object
     * @param handler       handler - allows access to other classes
     * @param x             x coordinate of the entity
     * @param y             y coordinate of the entity
     * @param width         width of the entity
     * @param height        height of the entity
     */
    public EntityNonLiving(Handler handler, float x, float y, int width, int height)
    {
        super(handler, x, y, width, height);
        // TODO Auto-generated constructor stub
    }
}
