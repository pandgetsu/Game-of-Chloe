/**
 * It's a grassTile
 * @author Sean Javadocing by Brian
 */
public class GrassTile extends Tile
{
    /**
     * Constructor for GrassTile
     * what's the point of this
     */
	public GrassTile(int id)
	{
		super(Assets.grassTile, id);
	}
}
