import java.awt.image.BufferedImage;

/**
 * Creates a spritesheet object
 * sprite sheet hold all sprites for entities
 * 
 * @author Sean Tran
 * @documenter Eric Kang
 * @version 1.0
 */
public class SpriteSheet 
{
    private BufferedImage mySheet;      // sprite sheet
    
    /**
     * Constructor for class SpriteSheet
     * 
     * @param sheet     the sprite sheet read in from file
     */
    public SpriteSheet(BufferedImage sheet)
    {
        mySheet = sheet;
    }
    
    /**
     * Crops the image to get an individual sprite
     * 
     * @return      individual sprite
     */
    public BufferedImage cropImage(int x, int y, int width, int height)
    {
        return mySheet.getSubimage(x, y, width, height);
    }

}
