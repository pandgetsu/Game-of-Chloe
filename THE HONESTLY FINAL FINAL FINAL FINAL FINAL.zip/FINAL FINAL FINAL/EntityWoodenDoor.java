import java.awt.Graphics;

/**
 * Creates a wooden door entity
 * 
 * @author Sean Tran
 * @documenter Eric Kang
 * @version 1.0
 */
public class EntityWoodenDoor extends EntityNonLiving
{
    private boolean isOpen;
    
    /**
     * Constructor for class EntityWoodenDoor
     * Sets isOpen to false to close the door
     * 
     * @param handler       handler - allows acces to other classes
     * @param x             x coordinate of the entity
     * @param y             y coordinate of the entity
     */
    public EntityWoodenDoor(Handler handler, float x, float y) 
    {
        super(handler, x, y, Tile.TILE_WIDTH, Tile.TILE_HEIGHT);
        // TODO Auto-generated constructor stub
        
        isOpen = false;
    }
    
    /**
     * Empty tick
     */
    public void tick()
    {

    }
    
    /**
     * Checks if the entity is alive
     * USELESS METHOD
     * 
     * @return      true
     */
    public boolean isAlive()
    {
        return true;
    }
    
    /**
     * Performs the action of the entity
     */
    public void getAction()
    {
        // If there are enemy entities still alive
            // Check if the player has gotten the key
            // If so, open the door and player uses up the key
            // Otherwise, print that a key is required
        // Otherwise, print that all enemy entities must be defeated first
        if(!myHandler.getInstance().getEntityHandler().checkAliveMobs())
        {
            if(myHandler.getInstance().getEntityHandler().getMainCharacter().isHasKey())
            {
                isOpen = true;
                System.out.println("Door is opened!");
                myHandler.getInstance().getEntityHandler().getEntityList().remove(EntityWoodenDoor.this);
                myHandler.getInstance().getEntityHandler().getMainCharacter().setHasKey(false);
            }else
            {
                System.out.println("A key is required!");
            }
        }else
        {
            System.out.println("All mobs must be cleared in the level before proceeding!");
        }
    }
    
    /**
     * Renders the image of the door
     */
    public void render(Graphics g)
    {
        if(!isOpen)
        {
            g.drawImage(Assets.woodenDoor, (int) getMyX(), (int) getMyY(), getMyWidth(), getMyHeight(), null);
        }
    }
    
    /**
     * Gets the entity signiture
     * 
     * @return      string with entity signature (type of entity)
     */
    @Override
    public String getEntitySignature()
    {
        return "door";
    }
}
