import java.awt.Graphics;
import java.awt.Rectangle;
import java.util.Observable;
import java.util.Observer;

/**
 * The Entity class is the very core of every entity object. It is an abstract class
 * that will require most of its lower hierarchy classes to have.
 */
public abstract class Entity
{
	protected Handler myHandler;
	
	//Positions of Entity
	protected float myX;
	protected float myY;
	
	//Dimensions of Entity
	protected int myWidth;
	protected int myHeight;
	
	//Collision Box Checking of Entity
	protected Rectangle boundingBox;
	protected static boolean checkAlive;
	

	//<<DEFAULT CONSTRUCTOR>>
	public Entity(Handler handler, float x, float y, int width, int height)
	{
		myHandler = handler;
		
		myX  = x;
		myY = y;
		
		myWidth = width;
		myHeight = height;
		
		checkAlive = true;
		
		boundingBox = new Rectangle(0, 0, myWidth, myHeight); //COLLISION BOX
	}
	
	/**
	 * Returns the boolean to determine if entity is alive
	 */
	public boolean isCheckAlive() 
	{
		return checkAlive;
	}

	/**
	 * Sets the alive state of the entity.
	 * Please disregard the naming of the method.
	 */
	public static void setCheckAlive(boolean wowAlive)
	{
		checkAlive = wowAlive;
	}
	
	public abstract boolean isAlive();
	
	public abstract String getEntitySignature();

	/**
	 * The isInteractable() method caclulates the distance of the player to the curren entity and if
	 * they are within a certain distance, they will be able to interact with the entity via space bar.
	 */
	public boolean isInteractable()
	{
		double differenceOfX = 0;
		double differenceOfY = 0;
		
		//int entityListLastIndex = myHandler.getInstance().getEntityHandler().getEntityList().size() - 1;

		
		try
		{
			differenceOfX = myHandler.getInstance().getEntityHandler().getMainCharacter().getMyX() - myX;
			differenceOfY = myHandler.getInstance().getEntityHandler().getMainCharacter().getMyY() - myY;
		}catch(NullPointerException e)
		{
			e.printStackTrace();
		}
		
		double distance = Math.sqrt(Math.pow(differenceOfX, 2)+ Math.pow(differenceOfY, 2)) / 32; //distance formula / 32 to convert pixels to tiles
		//double distance2 = Point2D.distance(myHandler.getInstance().getEntityHandler().getEntityList().get(2).getMyX(), myHandler.getInstance().getEntityHandler().getEntityList().get(2).getMyY(), myX, myY) / 32;
		
		
		if(distance <= 1.5)
		{
			return true;
		}
		
//		System.out.println("differenceOfX: " + differenceOfX);
//		System.out.println("differenceOfY: " + differenceOfY);
//		System.out.println("DISTANCE: " + distance);
		
		return false;
	}
	
	public abstract void getAction();
	
	/**
	 * The checkEntityCollisions() method checks if an entity is colliding with another entity
	 */
	public boolean checkEntityCollisions(float offsetX, float offsetY)
	{
		for(Entity ent : myHandler.getInstance().getEntityHandler().getEntityList())
		{
			if(ent.equals(this)) //if the entity is itself, continue the for loop
			{
				continue;
			}
			
			if(ent.getCollisionBounds(0.0f, 0.0f).intersects(getCollisionBounds(offsetX, offsetY))) //if is colliding
			{
				return true; //return true
			}
		}

		return false; //otherwise false
	}
	
	/**
	 * The getCollisionsBounds() returns the bounding box of an entity
	 */
	public Rectangle getCollisionBounds(float offsetX, float offsetY)
	{
		return new Rectangle((int) (myX + boundingBox.x + offsetX), (int) (myY + boundingBox.y + offsetY), boundingBox.width, boundingBox.height);
	}
	
	/**
	 * Returns the x coordinate of the entity
	 */
	public float getMyX() 
	{
		return myX;
	}

	/**
	 * Sets the x coordinate of the entity
	 */
	public void setMyX(float x) 
	{
		myX = x;
	}

	/**
	 * Returns the y coordinate of the entity
	 */
	public float getMyY()
	{
		return myY;
	}

	/**
	 * Sets the y coordinate of the entity
	 */
	public void setMyY(float y) 
	{
		myY = y;
	}

	/**
	 * Returns the width of the entity
	 */
	public int getMyWidth() 
	{
		return myWidth;
	}

	/**
	 * Sets the width of the entity
	 */
	public void setMyWidth(int width) 
	{
		myWidth = width;
	}

	/**
	 * Returns the height of the entity
	 */
	public int getMyHeight() 
	{
		return myHeight;
	}

	/**
	 * Sets the height of the entity
	 */
	public void setMyHeight(int height) 
	{
		myHeight = height;
	}

	//My dad wanted to help me with this, but it became more confusing.
	// public void addObserver(Observer obs)
	// {
		
		
	// }
	public abstract void tick();
	
	public abstract void render(Graphics g);

}
