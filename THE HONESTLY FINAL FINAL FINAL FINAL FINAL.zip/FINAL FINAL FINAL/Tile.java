import java.awt.Graphics;
import java.awt.image.BufferedImage;

/**
 * The Tile class holds the different tiles that may appear on the dungeon floor of the dungeon instance.
 */
public class Tile 
{
    //class variables
	public static Tile[] tiles = new Tile[256];
	
	//the integer in the parameter is the ID of the tile, utilized within the text file
	public static Tile grassTile = new GrassTile(0);
	public static Tile stoneTile = new StoneTile(1);
	public static Tile wallTile = new WallTile(2);
	public static Tile badTile = new BadTile(3);
	
	public static final int TILE_WIDTH = 32;
	public static final int TILE_HEIGHT = 32;
	
	protected BufferedImage tileTexture;
	protected final int tileID;

	/**
	 * Each tile is initialized with a texture and an ID.
	 */
	public Tile(BufferedImage texture, int id)
	{
		tileTexture = texture;
		tileID = id;
		
		tiles[id] = this;
	}

	/**
	 * There were plans for this tick() method but we determined it was for the best to abandon it and let it wither alone.
	 */
	public void tick()
	{
		//haaHAA
	}
	
	/**
	 * Renders the particular tile.
	 */
	public void render(Graphics g, int x, int y)
	{
		g.drawImage(tileTexture, x, y, TILE_WIDTH, TILE_HEIGHT, null);
	}
	
	/**
	 * Naturally, most of the tiles do not deal damage over time, with an exception of the BadTile. Can be overrided.
	 */
	public boolean dealsDOT()
	{
		return false;
	}
	
	/**
	 * Determines whether or not the tile can be walked over or not. Can be overrided.
	 */
	public boolean isSolid()
	{
		return false;
	}
	
	/**
	 * Returns the ID of the tile.
	 */
	public int getTileID()
	{
		return tileID;
	}
}
