import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

/**
 * The Utilities class purely just holds methods for file reading. I could have used Nevison's ConsoleIO, but nah.
 */
public class Utilities 
{
    //<<DEFAULT CONSTRUCTOR>>
    public Utilities()
    {
        //:^)
    }
    
    /**
     * The loadFile() expects a string that will act as the pathway for the BufferedReader to read to locate a particular file.
     */
	public static String loadFile(String path)
	{
		StringBuilder builder = new StringBuilder();
		
		try
		{
			BufferedReader br = new BufferedReader(new FileReader(path));
			String someString;
			
			while((someString = br.readLine()) != null)
			{
				builder.append(someString + "\n");
			}
			
			br.close(); //close connection
			
		}catch(IOException e)
		{
			e.printStackTrace();
		}
		
		return builder.toString();
	}
	
	/**
	 * Converts a string to an integer.
	 */
	public static int parseInt(String number)
	{
		try
		{
			return Integer.parseInt(number);
		}catch(NumberFormatException e)
		{
			e.printStackTrace();
			return 0;
		}
	}
}
