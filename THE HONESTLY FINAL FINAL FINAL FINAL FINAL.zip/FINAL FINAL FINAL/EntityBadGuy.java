import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.util.*;
/**
 * Class for the enemies of the game
 * @author Sean and Brian
 */
public class EntityBadGuy extends EntityLiving
{

    private final int ANIMATION_SPEED = 300;                        //The speed at which the animation plays
    private final int PROJECTILE_INTERVAL = 300;                    //Time until projectiles fire again
    private final int PROJECTILE_ANGLE = 15;                        //How many projectiles fire 360/PROJECTILE_ANGLE
    private Animation standing;                                     //Animation for the standing position
    private int projectileTime;                                     //Time until the projectiles can be fired again
    private int direction;                                          //Direction which the enemy is moving towards
    public EntityBadGuy(Handler handler, float x, float y) 
    {
        super(handler, x, y, Tile.TILE_WIDTH, Tile.TILE_HEIGHT);            //Constructs from EntityLiving constructor
        
        standing = new Animation(ANIMATION_SPEED, Assets.badGuy_standing);  //Gets the animtaion for the enemy standing
        projectileTime = PROJECTILE_INTERVAL;                               //Gets an initial delay for the projectiles
        chloe = new ArrayList<Projectile>();                                //Creates an arrayList for the projectiles
        moveX = (float)-.5;                                                 //Initial movement in the x direction
        moveY = (float)1;                                                   //Initial movement in the y direction
    }
    
    /**
     * The signature of the entity
     */
    public String getEntitySignature()
    {
        return "mob";
    }

    /**
     * Ticks the badguy
     * Makes him do the animation
     * makes it move
     * makes it shoot projectiles
     * checks the projectiles and sees if they are in bounds and not in the player
     * If they are remove them
     * Decrements projectileTime so the projectiles can be fired again
     */
    public void tick()
    {
        standing.tick();
        //checkSurrounding();
        move();
         if(projectileTime <= 100)
         {
            for(int x = 0; x < 360; x += PROJECTILE_ANGLE)
                shoot(x);
            projectileTime = PROJECTILE_INTERVAL;
        }
        for(int x = 0; x < chloe.size(); x++)
        {
            if(chloe.get(x).checkBounds() && !chloe.get(x).checkPlayer())
                chloe.get(x).tick();
            else
            {
                chloe.remove(x);
                x--;
            }
        }
        projectileTime--;
        
        //shoot();
//         
//         for(Entity e : myHandler.getInstance().getEntityHandler().getEntityList())
//         {
//             if(e.getEntitySignature().equals("Projectile"))
//             {
//                 e.tick();
//             }
//         }
    }
    
    /**
     * Moves along the x but checks which direction the enemy moves and if it collides with a tile then it moves in the oppositie direction
     * 
     */
    public void changeX()
    {
        //if move right
        if(moveX > 0)
        {
            int tempX = (int) (myX + moveX + boundingBox.x + boundingBox.width) / Tile.TILE_WIDTH;

            if(!collisionWithTile(tempX, (int) (myY + boundingBox.y) / Tile.TILE_HEIGHT) && !collisionWithTile(tempX, (int) (myY + boundingBox.y + boundingBox.height) / Tile.TILE_HEIGHT))
            {
                myX += moveX;
            }else
            {
                moveX *= -1;//myX *= -1;// tempX * Tile.TILE_WIDTH - boundingBox.x - boundingBox.width - 1;
            }
        }else if(moveX < 0)
        {
            int tempX = (int) (myX + moveX + boundingBox.x) / Tile.TILE_WIDTH;

            if(!collisionWithTile(tempX, (int) (myY + boundingBox.y) / Tile.TILE_HEIGHT) && !collisionWithTile(tempX, (int) (myY + boundingBox.y + boundingBox.height) / Tile.TILE_HEIGHT))
            {
                myX += moveX;
            }else
            {
                moveX *= -1;//myX *= -1;//tempX * Tile.TILE_WIDTH + Tile.TILE_WIDTH - boundingBox.x;
            }
        }
    }

    /**
     * Moves along the y but checks which direction the enemy moves and if it collides with a tile then it moves in the oppositie direction
     * 
     */
    public void changeY()
    {
        if(moveY < 0)
        {
            int tempY = (int) (myY + moveY + boundingBox.y) / Tile.TILE_HEIGHT;

            if(!collisionWithTile((int) (myX + boundingBox.x) / Tile.TILE_WIDTH, tempY) && !collisionWithTile((int) (myX + boundingBox.x + boundingBox.width) / Tile.TILE_WIDTH, tempY))
            {
                myY += moveY;
            }else
            {
                moveY *= -1;// tempY * Tile.TILE_HEIGHT + Tile.TILE_HEIGHT - boundingBox.y;
            }
        }else if(moveY > 0)
        {
            int tempY = (int) (myY + moveY + boundingBox.y + boundingBox.height) / Tile.TILE_HEIGHT;

            if(!collisionWithTile((int) (myX + boundingBox.x) / Tile.TILE_WIDTH, tempY) && !collisionWithTile((int) (myX + boundingBox.x + boundingBox.width) / Tile.TILE_WIDTH, tempY))
            {
                myY += moveY;
            }else
            {
                moveY *= -1;//myY *= -1;// tempY * Tile.TILE_HEIGHT - boundingBox.y - boundingBox.width - 1;
            }
        }
    }
    
    /**
     * Shoots the projectiles in a certain direction
     * 
     */
   public void shoot(int direction)
    {
        
        chloe.add(new Projectile(this, myHandler, myX, myY, myWidth, myHeight, direction * -1, "mob"));
        //myHandler.getInstance().getEntityHandler().addEntity(chloe);

    }
    
    /**
     * Calculates the angle for the player
     * Originally used for pathing and to 
     */
    public int calculatePlayerAngle()
    {
        int x = 0;
        int y = 0;
        x = (int)myHandler.getInstance().getEntityHandler().getMainCharacter().getMyX();
        y = (int)myHandler.getInstance().getEntityHandler().getMainCharacter().getMyY();
        x -= myX;
        y -= myY;
        
        return (int)Math.atan((double) y/x);
    }
    
    /**
     * Checks the surrounding area for the main characcter
     * Originally used to have the enemy to path towards the player
     * Replaced with random movement instead to factor against the mobs getting stuck
     */
    public void checkSurrounding()
    {
        double differenceOfX = 0;
        double differenceOfY = 0;
        
        moveX = 0;
        moveY = 0;

        //int entityListLastIndex = myHandler.getInstance().getEntityHandler().getEntityList().size() - 1;


        try
        {
            differenceOfX = myHandler.getInstance().getEntityHandler().getMainCharacter().getMyX() - myX;
            differenceOfY = myHandler.getInstance().getEntityHandler().getMainCharacter().getMyY() - myY;
        }catch(NullPointerException e)
        {
            e.printStackTrace();
        }

        double distance = Math.sqrt(Math.pow(differenceOfX, 2)+ Math.pow(differenceOfY, 2)) / 32;
        //double distance2 = Point2D.distance(myHandler.getInstance().getEntityHandler().getEntityList().get(2).getMyX(), myHandler.getInstance().getEntityHandler().getEntityList().get(2).getMyY(), myX, myY) / 32;


        if(distance <= 20)
        {
            if(myX < myHandler.getInstance().getEntityHandler().getMainCharacter().getMyX() - 32)
            {
                moveX++;
            }else if(myX > myHandler.getInstance().getEntityHandler().getMainCharacter().getMyX() + 32)
            {
                moveX--;
            }

            if(myY < myHandler.getInstance().getEntityHandler().getMainCharacter().getMyY() - 32)
            {
                moveY++;
            }else if(myY > myHandler.getInstance().getEntityHandler().getMainCharacter().getMyY() + 32)
            {
                moveY--;
            }
        }
        
        if(distance <= 1.5)
        {
            attack(myHandler.getInstance().getEntityHandler().getMainCharacter());
        }
    }
    
    /**
     * Gets the action of this entity
     * This one is to take damage
     */
    public void getAction()
    {
        getDamaged();
    }

    /**
     * Renders out the enemies and such
     */
    public void render(Graphics g)
    {
        for(Projectile p : chloe)
        {
            p.render(g);
        }
//         chloe.render(g);
        if(getStat_HP() > 0)
        {
            g.drawImage(getCurrentAnimation(), (int) getMyX(), (int) getMyY(), getMyWidth(), getMyHeight(), null);
            
        }
    }
    
    /**
     * Gets the animation for the mob
     */
    private BufferedImage getCurrentAnimation()
    {
        return standing.getCurrentSprite();
    }

}