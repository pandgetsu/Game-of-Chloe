/**
 * Stone tile it's a ground tile
 * @author Sean and javadocing by sean
 */
public class StoneTile extends Tile
{
    /**
     * Constructor for the StoneTile class
     */
	public StoneTile(int id)
	{
		super(Assets.stoneTile, id);
	}
}
