import java.awt.Graphics;
import java.awt.image.BufferStrategy;

/**
 * The large bulk of the game occurs here and the actual ingame timer is located in this class as well.
 * Many of the game's aspects are initiated here, and will be reused as objects throughout many different
 * classes within the program.
 * 
 * @author Sean Tran
 * @co-author Francis Nguyen
 */
public class DungeonGame implements Runnable
{
    //class variables
    private DungeonGUI myDisplay;
    
    private String myTitle;
    private int myWidth;
    private int myHeight;
    
    public static boolean myFlashlight;

    private boolean gameRunning;
    private Thread myThread;
    
    private BufferStrategy myBuffer;
    private Graphics myGraphics;
    
    private State dungeonState;
    
    private Keyboard keyboard;
    
    private Handler handler;
    
    private MasterGUI myMaster;
    private Heroine myGirl;
    
    //<<DEFAULT CONSTRUCTOR>>
    /**
     * This constructor initiates a lot of important aspects of the game such as the title along with the dimensions of the game.
     */
    public DungeonGame(String title, int width, int height , boolean flashlight, MasterGUI parent, Heroine girl)
    {
        myTitle = title;
        myWidth = width;
        myHeight = height;
        
        myMaster = parent;
        
        myFlashlight = flashlight;
        
        gameRunning = false;
        
        keyboard = new Keyboard();
        
        myGirl = girl;
    }
    
    /**
     * The initGame() method does the necessary preparations in order for the program to run.
     * Some processes that are handled within this method is: - Loading in of assets
     *                                                        - The creation of the Handler object (This class is by far one of the greatest creations of Sean Tran)
     *                                                        - Creation of GUI
     *                                                        - Setting game state to the dungeon level.
     */
    private void initGame()
    {
        Assets.init(); //loads assets before running of program
        
        handler = new Handler(this); //you will love this
        
        handler.setDungeon(myGirl.getDungeon()); //gets current dungeon to be played
        myDisplay = new DungeonGUI(myTitle, handler, myMaster); //creates display of game
        myDisplay.getFrame().addKeyListener(keyboard); //adds frame to display of game
                
        handler.addGUI(myDisplay); //makes display accessible through handler
        keyboard.addHandler(handler); //makes handler accessible through keyboard
        
        dungeonState = new DungeonState(handler); //creates dungeon state sent handler so it can access stuff
        State.setState(dungeonState); //set current game state to dungeon state
    }
    
    /**
     * The tick() method updates the contents of the method.
     * In this case, the keyboard, display, and state of the game is ticked.
     * 
     * As you will see in the JavaDOCs of those classes, there will be ticks within those classes
     * that will tick other objects as well.
     */
    private void tick()
    {
        keyboard.tick();
        myDisplay.tick();
        
        if(State.getState() != null)
        {
            State.getState().tick();
        }
    }
    
    /**
     * The drawToScreen() method prepares the GUI
     * by binding graphics and a canvas to the display.
     */
    private void drawToScreen()
    {
        myBuffer = myDisplay.getCanvas().getBufferStrategy();
        
        if(myBuffer == null)
        {
            myDisplay.getCanvas().createBufferStrategy(2); //creates a new strategy for multi-buffering of canvas
            return;
        }
        
        myGraphics = myBuffer.getDrawGraphics(); //creates graphics for the buffer
        
        myGraphics.clearRect(0, 0, myWidth, myHeight); //clear everythinggggggggggggggg

        if(State.getState() != null)
        {
            State.getState().render(myGraphics);
        }
        
        myBuffer.show(); //makes buffer visible
        myGraphics.dispose(); //clears graphics
    }

    /**
     * Return width of game
     */
    public int getWidth() 
    {
        return myWidth;
    }

    /**
     * Set width of game
     */
    public void setWidth(int width) 
    {
        myWidth = width;
    }

    /**
     * Return height of game
     */
    public int getHeight() 
    {
        return myHeight;
    }

    /**
     * Set height of game
     */
    public void setHeight(int height)
    {
        myHeight = height;
    }

    /**
     * The run() method is the core method that runs the entire program. It checks whether or not the
     * game should still be running and is what the tick() methods are running off of.
     * 
     * The timer of the game is also handled within this method and the way that it is calculated can
     * be attributed to a handy dandy post on StackOverflow.
     */
    public void run()
    {
        initGame(); //prepares game
        
        //stack overflow woohoo, does calculations for fps and ingame time so ill just
        //leave this comment for the majority of the code below :^)
        final int FPS = 60;
        double timePerTick = 1000000000/ FPS;
        double delta = 0;
        long now;
        long lastTime = System.nanoTime();
        long timer = 0;
        int ticks = 0;
        
        while(gameRunning) //while game is running
        {
            now = System.nanoTime();
            delta += (now - lastTime) / timePerTick;
            timer += now - lastTime;
            lastTime = now;
            
            if(delta >= 1)
            {
                tick();
                drawToScreen();
                
                ticks++;
                delta--;
            }
            
            if(timer >= 1000000000)
            {
                System.out.println("FPS: " + ticks);
                ticks = 0;
                timer = 0;
            }
        }
        
        stop(); //stop program
    }
    
    /**
     * Returns the keyboard object
     */
    public Keyboard getKeyboard()
    {
        return keyboard;
    }
    
    /**
     * Begins threading of game
     */
    public void start()
    {
        if(gameRunning)
            return;
        
        gameRunning = true;
        
        myThread = new Thread(this);
        myThread.start();
    }
    
    /**
     * Stops the program
     */
    public void stop()
    {
        if(!gameRunning)
            return;
        
        gameRunning = false; //set this to false. yes.
        myDisplay.setVisible(false); //turn off display
        myMaster.backToMenu(); //returns user to menu
        //System.exit(1);;
        
        try 
        {
            myThread.join();
        } catch (InterruptedException e) 
        {
            e.printStackTrace();
        }
    }
    
    /**
     * The VNScene() method returns user directly to the visual novel and closes the dungeon program.
     */
    public void VNScene()
    {
        if(!gameRunning)
            return;
        
        gameRunning = false;
        myDisplay.setVisible(false);
        myGirl.setIsFound(true);
        myMaster.doneWithStart();
         //myMaster.goToVisualNovel("resources/scenes/testDiag.txt"); 
        myMaster.goToVisualNovel(myGirl); 
        //System.exit(1);;
        
        try 
        {
            myThread.join();
        } catch (InterruptedException e) 
        {
            e.printStackTrace();
        }
       }

}
