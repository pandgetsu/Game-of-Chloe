import java.awt.Graphics;

/**
 * Creates a girl entity
 * 
 * @author Sean Tran
 * @documenter Eric Kang
 * @version 1.0
 */
public class EntityGirl extends EntityNonLiving
{
    /**
     * Constructor for class EntityGirl
     * 
     * @param handler       handler - allows acces to other classes
     * @param x             x coordinate of the entity
     * @param y             y coordinate of the entity
     */
    public EntityGirl(Handler handler, float x, float y) 
    {
        super(handler, x, y, Tile.TILE_WIDTH, Tile.TILE_HEIGHT);
    }
    
    /**
     * Empty tick
     */
    public void tick()
    {
        
    }
    
    /**
     * Renders the image of the girl
     */
    public void render(Graphics g)
    {
        g.drawImage(Assets.chloeEntity.get(myHandler.getDungeon() - 1), (int) getMyX(), (int) getMyY(), getMyWidth(), getMyHeight(), null);
    }
    
    /**
     * Gets the entity signiture
     * 
     * @return      string with entity signature (type of entity)
     */
    public String getEntitySignature()
    {
        return "girl";
    }
    
    /**
     * Checks if the entity is alive
     * USELESS METHOD
     * 
     * @return      true;
     */
    public boolean isAlive()
    {
        return true;
    }
    
    /**
     * Performs the action of the entity
     */
    public void getAction()
    {
        myHandler.getGame().VNScene(); //*********
    }

}
