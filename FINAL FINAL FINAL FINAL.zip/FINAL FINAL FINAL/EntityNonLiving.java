

public abstract class EntityNonLiving extends Entity
{

	public EntityNonLiving(Handler handler, float x, float y, int width, int height)
	{
		super(handler, x, y, width, height);
		// TODO Auto-generated constructor stub
	}
	


}
