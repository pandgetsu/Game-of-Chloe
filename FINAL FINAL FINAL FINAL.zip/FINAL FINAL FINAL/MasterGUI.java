import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
/**
 * MasterGUI is the main JFrame that contains all the other JPanels that are displayed to the user
 * Contains methods to swap JPanels and to launch the DungeonGame
 * 
 * 
 * @author Francis Nguyen
 * @version 05
 */
public class MasterGUI extends JFrame implements ActionListener
{
    private MenuGUI menu;
    private JPanel currentPanel; 
    private JPanel dummyPanel;
    private ArrayList<Heroine> heroineList;
    private String playerName = "Mark";
    
    /**
     * Constructor that that sets various elements for the JFrame like the title starts with the JPanel enterNameGUI
     * 
     * Sets up the ArrayList of Heroines, refer to class Heroine for more information
     */
    public MasterGUI(){
        initGirlList();

        
        setTitle("TGoC - The Game of Chloe");
        setSize(960, 720);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(true);
        menu = new MenuGUI(this, heroineList);
        //add(menu);
        add(new enterNameGUI(this));
        
        dummyPanel = new JPanel();
        dummyPanel.add(new JLabel("wow!"));
        pack();
        setVisible(true);
    }
    /**
     * For purposes of JButtons that require action listeners and responds depending on the command string
     * 
     * dummyPanel should not be launched unless the command string is incorrect
     */
    public void actionPerformed(ActionEvent e){
        String command = e.getActionCommand();
        if(command.equals("") || command.equals("menu"))
            backToMenu();
        else
            if(command.equals("Start Game"))
            {
                goToVisualNovel("resources/scenes/start/start01.txt");
            }   
            else
                if(command.equals("Results"))
                {
                    swapPanels(new ResultsGUI(heroineList, this));
                }
                    else
                        swapPanels(dummyPanel);
    }    
    /**
     * Swaps JPanels from the current panel to the newPanel
     */
    private void swapPanels(JPanel newPanel)
    { 
        getContentPane().removeAll();
        add(newPanel, BorderLayout.CENTER);
        revalidate();
        repaint();
    }
    /**
     * Similar to swapPanel except always swaps to MenuGUI
     */
    public void backToMenu()
    {
        getContentPane().removeAll();
        menu.checkState();
        add(menu);
        revalidate();
        repaint();
        pack();
    }
    /**
     * Opens up a new instance of DungeonGame with the tutorial dungeon specifically
     */
    public void goToDungeon()
    {
        swapPanels(new inGame());
        DungeonGame TGOC = new DungeonGame("The Game of Chloe", 960, 720, false, this, heroineList.get(0)); //(Game Title, Width, Height, Flashlight)
        TGOC.start();
    }
    /**
     * Opens up a new instance of DungeonGame with the dungeon based of which Heroine was inputed
     */
    public void goToDungeon(Heroine h)
    {
        swapPanels(new inGame());
        DungeonGame TGOC = new DungeonGame("The Game of Chloe", 960, 720, false, this, h); //(Game Title, Width, Height, Flashlight)
        TGOC.start();
    }
    /**
     * Swaps to the VisualNovelGUI and loads information based off a text file
     */
    public void goToVisualNovel(String fileName)
    {
        getContentPane().removeAll();
        add(new VisualNovelGUI(fileName, this));
        revalidate();
        repaint();
        pack();
    }
    public void goToVisualNovel(Heroine h)
    {
        getContentPane().removeAll();
        add(new VisualNovelGUI(h.getScene(), h, this));
        revalidate();
        repaint();
        pack();
    }
    public void setPlayerName(String pName)
    {
        playerName = pName;
    }
    public String getPlayerName()
    {
        return playerName;
    }
    public void doneWithStart()
    {
        menu.setPostStart(true);
    }
    private void initGirlList()
    {
        heroineList = new ArrayList<Heroine>(4);
        heroineList.add(new Heroine("Chloe", 1));
        heroineList.add(new Heroine("Illya", 2));
        heroineList.add(new Heroine("Celica", 3));
        heroineList.add(new Heroine("Grill", 4));
    }
    
}
